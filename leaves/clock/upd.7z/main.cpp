#include <iostream>
#include <string>
#include <Windows.h>
#include <cstdio>
#include <conio.h>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <chrono>
using namespace std;

bool eng = 0; //v1.2.0 �ٸ���  
bool white = 1, green = 0, fast = 0; //��ɫ���Ǻ�ɫ  ����  �ӿ���л 
bool _return = 0; //ֱ��ȥ��  
HWND hwnd = FindWindow(NULL, "��ʱ�� v1.1.0");
int sz = 1; //����ѡ�� 
SYSTEMTIME wtime; //ʱ��  
struct time
{
    int year;
    int month;
    string week;
    int day;
    int hour;
    int minute;
    int second;
} ti;

void setcolor(WORD color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

// �޸��ļ�ʱ����
class FixedTimer {
private:
    std::chrono::steady_clock::time_point start_time;
    std::chrono::steady_clock::time_point pause_start_time;
    double total_paused_time = 0; // �ۼ���ͣʱ��
    bool is_paused = false;

public:
    void start() {
        start_time = std::chrono::steady_clock::now();
        is_paused = false;
        total_paused_time = 0;
    }

    void pause() {
        if (!is_paused) {
            pause_start_time = std::chrono::steady_clock::now();
            is_paused = true;
        }
    }

    void resume() {
        if (is_paused) {
            auto resume_time = std::chrono::steady_clock::now();
            total_paused_time += std::chrono::duration<double>(resume_time - pause_start_time).count();
            is_paused = false;
        }
    }

    double getElapsedSeconds() const {
        if (is_paused) {
            return std::chrono::duration<double>(pause_start_time - start_time).count() - total_paused_time;
        } else {
            auto current_time = std::chrono::steady_clock::now();
            return std::chrono::duration<double>(current_time - start_time).count() - total_paused_time;
        }
    }

    bool paused() const {
        return is_paused;
    }
};

void gettime()
{
    GetLocalTime(&wtime);
    ti.year = wtime.wYear;
    ti.month = wtime.wMonth;
    int week = wtime.wDayOfWeek;
    string we;
    switch (week)
    {
    case 1:
    {
        we = "һ";
        break;
    }
    case 2:
    {
        we = "��";
        break;
    }
    case 3:
    {
        we = "��";
        break;
    }
    case 4:
    {
        we = "��";
        break;
    }
    case 5:
    {
        we = "��";
        break;
    }
    case 6:
    {
        we = "��";
        break;
    }
    case 0:
    {
        we = "��";
        break;
    }
    }
    ti.week = we;
    ti.day = wtime.wDay;
    ti.hour = wtime.wHour;
    ti.minute = wtime.wMinute;
    ti.second = wtime.wSecond;
}

void color(short x)
{

    if (x == 15)
        if (white == 1 && green == 0)
            system("color F0");
        else if (green == 1)
            system("color 27");
        else
            system("color 0F");
    else if (x == 2)
        if (white == 1 && green == 0)
            system("color FA");
        else if (green == 1)
            system("color 2A");
        else
            system("color 0A");
    else if (x == 12)
        if (white == 1 && green == 0)
            system("color FC");
        else if (green == 1)
            system("color 2C");
        else
            system("color 0C");
    else if (x == 11)
        if (white == 1 && green == 0)
            system("color FB");
        else if (green == 1)
            system("color 2B");
        else
            system("color 0B");
}

void watch()
{
	WORD c1 = 16 | 128 , c2 = 64 | 128 , c3 = 32 | 128 ;
    int s_w = 7; //���볤�� 
    int m_w = 5; //���볤�� 
    int h_w = 3; //ʱ�볤�� 
    int xs[17][17] = { 0 };
    double s = 0, f = 0, m = 0;
    char sr = ' ';
    while (sr != 'r')
    {
        system("cls");
        if (_kbhit())
		{
			sr = _getch() ;
			if(sr == 'r')
				break ;
		}
        time_t t = time(0);
        tm* temp = localtime(&t);
        s = temp->tm_hour;
        f = temp->tm_min;
        m = temp->tm_sec;
        f += m / 60;
        s += f / 60;
        m *= 6;
        f *= 6;
        s *= 30;
        xs[9][9] = true;
        int m1, m2;
        m1 = int(-cos((360 - m) / 180.0 * 3.14) * s_w + 9);
        m2 = int(-sin((360 - m) / 180.0 * 3.14) * s_w + 9);
        xs[m1][m2] = true;
        int f1, f2;
        f1 = int(-cos((360 - f) / 180.0 * 3.14) * m_w + 9);
        f2 = int(-sin((360 - f) / 180.0 * 3.14) * m_w + 9);
        xs[f1][f2] = true;
        int s1, s2;
        s1 = int(-cos((360 - s) / 180.0 * 3.14) * h_w + 9);
        s2 = int(-sin((360 - s) / 180.0 * 3.14) * h_w + 9);
        xs[s1][s2] = true;
        for (double i = 0; i < 1; i += 0.14)
        {
            xs[int(9 * i + m1 * (1 - i))][int(9 * i + m2 * (1 - i))] = 1 ;
            xs[int(9 * i + f1 * (1 - i))][int(9 * i + f2 * (1 - i))] = 2 ;
            xs[int(9 * i + s1 * (1 - i))][int(9 * i + s2 * (1 - i))] = 3 ;
        }
        for (int i = 0; i < 17; ++i)
        {
            for (int j = 0; j < 17; ++j)
            {
                if (xs[i][j] == 1)
                    //setcolor(114);
                    setcolor(c1);   // ��ɫ (��ɫ+��ɫ = 1+2)
                else if(xs[i][j] == 2)
                	setcolor(c2) ;
                else if(xs[i][j] == 3)
                	setcolor(c3) ;
                else
                    setcolor(0);
                if (j == 9 && i == 0)
                {
                    setcolor(8);
                    printf("12\n");
                    printf("                  |");
                }
                else if (j == 9 && i == 16)
                {
                    setcolor(8);
                    printf(" |\n");
                    printf("                   6\n");
                }
                else if (j == 0 && i == 9)
                {
                    setcolor(8);
                    printf("9__");
                }
                else if (j == 16 && i == 9)
                {
                    setcolor(8);
                    printf("__3");
                }
                else
                    printf("  ");
                xs[i][j] = false;
            }
            printf("\n");
        }

        setcolor(8);
        cout << "\n\n        ��r������������";
        gettime();
        printf("\n       ����ʱ�� %02d:%02d:%02d", ti.hour, ti.minute, (ti.second + 59) % 60);
        setcolor(c1) ;
        cout << "\n            ����            \n" ;
        setcolor(c2) ;
        cout << "            ����            \n" ;
        setcolor(c3) ;
        cout << "            ʱ��            " ;
        m /= 6;
        f /= 6;
        s /= 30;
        Sleep(800);
        setcolor(0) ;
    }
}
void watch_ai()
{
    int hour = 0, minute = 0, second = 0;
    char sr = ' ';
    
    while (sr != 'r' && sr != 'R')
    {
        system("cls");
        
        // ��ȡ��ǰʱ��
        time_t t = time(0);
        tm* temp = localtime(&t);
        hour = temp->tm_hour;
        minute = temp->tm_min;
        second = temp->tm_sec;
        
        // ���ÿ���̨���ڴ�С
        system("mode con cols=50 lines=25");
        
        // ʱ�ӱ���
        setcolor(11);
        cout << "        �X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[\n";
        cout << "        �U         ģ��ʱ��         �U\n";
        cout << "        �d�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�g\n";
        printf("        �U         %02d:%02d:%02d         �U\n", hour, minute, second);
        cout << "        �^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a\n\n";
        
        // ����ASCII��������
        setcolor(15);
        cout << "              .--.  .--.\n";
        cout << "             |    ||    |\n";
        cout << "           .-'-.  ||  .-'-.\n";
        cout << "         .'     '.||.'     '.\n";
        cout << "        |   12    ||    1    |\n";
        cout << "        |         ||         |\n";
        cout << "        |   11    ||    2    |\n";
        cout << "         '.     .'||'.     .'\n";
        cout << "           '-.-'  ||  '-.-'\n";
        cout << "             |    ||    |\n";
        cout << "           .-'-.  ||  .-'-.\n";
        cout << "         .'     '.||.'     '.\n";
        cout << "        |   10    ||    3    |\n";
        cout << "        |         ||         |\n";
        cout << "        |    9    ||    4    |\n";
        cout << "         '.     .'||'.     .'\n";
        cout << "           '-.-'  ||  '-.-'\n";
        cout << "             |    ||    |\n";
        cout << "           .-'-.  ||  .-'-.\n";
        cout << "         .'     '.||.'     '.\n";
        cout << "        |    8    ||    5    |\n";
        cout << "        |         ||         |\n";
        cout << "        |    7    ||    6    |\n";
        cout << "         '.     .'||'.     .'\n";
        cout << "           '-.-'  ||  '-.-'\n";
        cout << "             '--'  '--'\n\n";
        
        // ��ʾָ��״̬
        cout << "   ָ��״̬:\n";
        setcolor(12); cout << "   �� ���� ";
        setcolor(10); cout << "�� ���� ";
        setcolor(11); cout << "�� ʱ��\n";
        
        setcolor(8);
        cout << "\n    �� R ������������\n";
        
        // ���������̼��
        if (_kbhit())
        {
            sr = _getch();
        }
        
        Sleep(500);
    }
    
    // �ָ�ԭ���Ŀ���̨��С
    system("mode con cols=31 lines=20");
}
void watch_ai2()
{
    int hour = 0, minute = 0, second = 0;
    char sr = ' ';
    
    while (sr != 'r' && sr != 'R')
    {
        system("cls");
        
        // ��ȡ��ǰʱ��
        time_t t = time(0);
        tm* temp = localtime(&t);
        hour = temp->tm_hour;
        minute = temp->tm_min;
        second = temp->tm_sec;
        
        // ���ı�ʱ�ӽ���
        setcolor(11);
        cout << "    �X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[\n";
        cout << "    �U   ģ��ʱ��   �U\n";
        cout << "    �d�T�T�T�T�T�T�T�T�T�T�T�T�T�T�g\n";
        printf("    �U   %02d:%02d:%02d    �U\n", hour, minute, second);
        cout << "    �^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a\n\n";
        
        // �򻯵ı���
        setcolor(15);
        cout << "        12\n";
        cout << "    11      1\n";
        cout << "  10          2\n";
        cout << " 9       ��      3\n"; 
        cout << "  8            4\n";
        cout << "    7       5\n";
        cout << "        6\n";
        
        setcolor(8);
        cout << "\n    �� R ������������";
        
        if (_kbhit())
        {
            sr = _getch();
        }
        
        Sleep(500);
    }
}
void qp()
{
    system("cls");
}

void sc(string x[], int len)
{
    color(11);
    for (int i = 0; i < len; i++)
    {
        cout << x[i];
        if (!fast)
            Sleep(140);
    }
    cout << '\n';
}

void mx()
{
    string a[] = { "8", "1", "3", "3", "��", "��", "��", "&", "l", "e", "a", "v", "e", "s", "��", "��", "��", "��", "Ʒ" };
    string b[] = { "��", "��", ":", "8", "1", "3", "3", "w", "t", "5", ",", "��", "Ҷ", "��", "��" };
    string c[] = { "��", "л", "D", "E", "V", " ", "C", "+", "+", "5", ".", "1", "1", "��", "��", "��", "��", "��", "��", "��" };
    string d[] = { "��", "��", "��", "��", "��", "1", "3", "��", "��", "��", "��", ",", "��", "��", "��", "֧", "��", "!" };
    sc(a, 19);
    sc(b, 15);
    sc(c, 20);
    sc(d, 18);
}

void print(string middle, bool flag, bool flag2) //middle������ģ�flag���������ͷ flag2����������� 
{
    if (flag2)
        cout << "|" << " ";
    if (flag)
        cout << "=>";
    else
        cout << "  ";
    cout << middle;
    if (flag)
        cout << "<=";
    else
        cout << "  ";
    if (flag2)
        cout << " " << "|" << '\n';
    else
        cout << "\n";
}

// ��ʽ��ʱ����ʾ������ֻ��ʾ���룩
void formatTime(double totalSeconds, bool isCountdown = false) {
    int total = static_cast<int>(totalSeconds);
    int hours = total / 3600;
    int minutes = (total % 3600) / 60;
    int seconds = total % 60;
    
    if (hours > 0) {
        printf("%dСʱ%02d����%02d��", hours, minutes, seconds);
    } else if (minutes > 0) {
        printf("%02d����%02d��", minutes, seconds);
    } else {
        printf("%02d��", seconds);
    }
}

int main()
{
    system("color F0");
    system("mode con cols=31 lines=20");
    SetConsoleTitle("��ʱ�� v1.1.02");
    if(!system("upd check 1.1.02"))
    {
        cout<<"��⵽�˸��£�����"<<endl;
        if(!system("upd log"))
        {
        	cout<<"���ڴ���־����"<<endl;
            system("start %temp%\\upd\\upd_log.txt");
        }
        system("pause");
		cout<<"��ʼ���ظ��¡���"<<endl; 
        if(!system("upd run"))
        {
            exit(0);
        }
        cout<<"���ظ���ʧ�ܣ����ֶ����ػ����ԣ�����"<<endl;
        system("pause"); 
    }
    int n = 1;
    while (1)
    {
        qp();
        color(15);
        while (1)
        {
            gettime();
            if (_return)
                break;
            qp();
            cout << "�ԡԡԡԡԡԡԡԡԡԡԡԡԡ�\n";
            cout << "|           ��ʱ��          |\n";
            cout << "|       �汾:Windows  7     |\n";
            cout << "| ��һ�θ���ʱ��:2025/11/26 |\n";
            printf("|������%04d��%02d��%02d�� ", ti.year, ti.month, ti.day);
            cout << "����" << ti.week << "|" << '\n';
            printf("|          %02dʱ%02d��         |\n", ti.hour, ti.minute);
            //                                      |����  
            cout << "| �ԡԡԡԡԡԡԡԡԡԡԡԡ�|\n";
            print("       1.����ʱ      ", n == 1, 1);
            print("       2.����ʱ      ", n == 2, 1);
            print("      3.�˳�����     ", n == 3, 1);
            print("        4.��л       ", n == 4, 1);
            print("     5.��ɫѡȡ��    ", n == 5, 1);
            print("      6.��������     ", n == 6, 1);
            print("        7.����       ", n == 7, 1);
            print("   8.ʱ��ģʽ(��ɫ)  ", n == 8, 1);
            cout << "|         ��w�����Ƽ�ͷ     |\n";
            cout << "|         ��s�����Ƽ�ͷ     |\n";
            cout << "|          ��r��ˢ��        |\n";
            cout << "|          ��h����ԭ        |\n";
            cout << "|  ��c��ѡ���ͷ���ڵ���Ŀ  |\n";
            cout << "| �ԡԡԡԡԡԡԡԡԡԡԡԡ�|\n";
            char ch = getch();
            if (ch == 's' || ch == 'S')//���� 
                n = (n == 8 ? 1 : n + 1);
            else if (ch == 'w' || ch == 'W')//���� 
                n = (n == 1 ? 8 : n - 1);
            else if (ch == 'c')//ȷ�� 
            {
                break;
            }
            else if (ch == 'h') //��ԭ 
            {
                n = 1;
            }
            else if (ch == '8')
            {
                qp();
                cout << "�ʵ�1\n";
                cout << "����Աģʽ�������һλ��8\n";
                cout << "�����������";
                _getch();
            }
            else if (ch == 'r')
                continue;
        }
        if (_return)
            break;
        if (n > 8 || n < 1)
        {
            bool flag = 1;
            while (flag)
            {
                qp();
                cout << "�������!\n";
                cout << "n = " << n << '\n';
                cout << "�����������";
                Sleep(300);
                for (int i = 0; i < 3; i++)
                {
                    Sleep(300);
                    cout << '.';
                    if (_kbhit())
                    {
                        char ch = _getch();
                        flag = 0;
                        break;
                    }
                }
            }
            continue;
        }
        if (n == 8)
        {
            int w = white;
            int g = green;
            white = 0;
            green = 0;
            color(15);
            watch();
            white = w;
            green = g;
        }
        else if (n == 3)
            break;
        else if (n == 4)
        {
            system("mode con cols=33 lines=17");
            qp();
            mx();
            cout << "��������˳���л����";
            char ch = _getch();
            system("mode con cols=31 lines=20");
            if (ch == '1')
            {
                qp();
                cout << "�ʵ�2\n";
                cout << "����Ա����ڶ�λΪ1\n";
                cout << "�����������";
                ch = getch();
                if (ch == 'w')
                {
                    qp();
                    cout << "�ʵ�2\n";
                    cout << "����Ա����ڶ�λΪ1\n";
                    cout << "�����������";
                    ch = getch();
                    if (ch == 't')
                    {
                        qp();
                        cout << "�ʵ�2\n";
                        cout << "����Ա����ڶ�λΪ1\n";
                        cout << "�����������";
                        ch = getch();
                        if (ch == 'h')
                        {
                            qp();
                            cout << "�ʵ�3\n";
                            cout << "�������������ʵ�����\n";
                            getch();
                            cout << "\n��Ķ�������������𣿣���";
                            Sleep(50);
                            qp();
                            cout << 3;
                            Sleep(500);
                            qp();
                            cout << 2;
                            Sleep(500);
                            qp();
                            cout << 1;
                            Sleep(500);
                            qp();
                            cout << "����";
                            Sleep(500);
                            qp();
                            cout << "�����������\n";
                            cout << "��200���ٶ�Ŷ!";
                            cout << "[����]";
                            Sleep(300);
                            for (int i = 0; i < 200; i++)
                            {
                                system("start https://www.baidu.com");
                            }
                            _return = 1;
                            break;
                        }
                    }
                }
            }
        }
        else if (n == 1)
        {
            qp();
            string name;
            cout << "�������ʱ����(����):";
            cin >> name;
            
            FixedTimer timer;
            timer.start();
            bool running = true;
            
            while (running)
            {
                // ����״̬
                while (!timer.paused() && running)
                {
                    qp();
                    color(2);
                    cout << "��ʱ: " << name;
                    cout << "״̬ : ";
                    cout << "��ʱ��\n\n";
                    cout << "��'b'����ͣ\n��'r'������\n\n";
                    cout << "�ѹ�ȥ��";
                    formatTime(timer.getElapsedSeconds());
                    
                    // ��鰴������
                    if (_kbhit()) {
                        char ch = _getch();
                        if (ch == 'b') {
                            timer.pause();
                            break;
                        } else if (ch == 'r') {
                            running = false;
                        }
                    }
                    Sleep(100); // ����ˢ��Ƶ��
                }
                
                // ��ͣ״̬
                while (timer.paused() && running)
                {
                    qp();
                    color(12);
                    cout << "��ʱ: " << name;
                    cout << "״̬ : ";
                    cout << "����ͣ\n\n";
                    cout << "��'c'������\n��'r'������\n\n";
                    cout << "�ѹ�ȥ��";
                    formatTime(timer.getElapsedSeconds());
                    
                    char ch = _getch();
                    if (ch == 'c') {
                        timer.resume();
                        break;
                    } else if (ch == 'r') {
                        running = false;
                    }
                }
            }
        }
        else if (n == 2)
        {
            qp();
            string name;
            cout << "�������ʱ����(����):";
            cin >> name;
            qp();
            cout << "Сʱ��(С��65536):";
            short h, m, s;
            cin >> h;
            qp();
            cout << "������:";
            cin >> m;
            qp();
            cout << "����:";
            cin >> s;
            if (h > 65535 || m > 59 || s > 59 || h < 0 || m < 0 || s < 0)
            {
                cout << "���벻�Ϸ�!\n";
                cout << "�����������";
                _getch();
                continue;
            }
            
            double totalSeconds = (h * 60.0 + m) * 60.0 + s;
            FixedTimer timer;
            timer.start();
            bool running = true;
            bool completed = false;
            
            while (running && !completed)
            {
                // ����״̬
                while (!timer.paused() && running && !completed)
                {
                    double elapsed = timer.getElapsedSeconds();
                    double remaining = totalSeconds - elapsed;
                    
                    if (remaining <= 0) {
                        completed = true;
                        break;
                    }
                    
                    qp();
                    color(2);
                    cout << "��ʱ: " << name;
                    cout << "״̬ : ";
                    cout << "��ʱ��\n\n";
                    cout << "��'b'����ͣ\n��'r'������\n\n";
                    cout << "��ʣ";
                    formatTime(remaining, true);
                    
                    // ��鰴������
                    if (_kbhit()) {
                        char ch = _getch();
                        if (ch == 'b') {
                            timer.pause();
                            break;
                        } else if (ch == 'r') {
                            running = false;
                        }
                    }
                    Sleep(100); // ����ˢ��Ƶ��
                }
                
                // ��ͣ״̬
                while (timer.paused() && running && !completed)
                {
                    double elapsed = timer.getElapsedSeconds();
                    double remaining = totalSeconds - elapsed;
                    
                    qp();
                    color(12);
                    cout << "��ʱ: " << name;
                    cout << "״̬ : ";
                    cout << "����ͣ\n\n";
                    cout << "��'c'������\n��'r'������\n\n";
                    cout << "��ʣ";
                    formatTime(remaining, true);
                    
                    char ch = _getch();
                    if (ch == 'c') {
                        timer.resume();
                        break;
                    } else if (ch == 'r') {
                        running = false;
                    }
                }
            }
            
            // ��ʱ���
            if (completed)
            {
                bool flag = true;
                while (flag)
                {
                    qp();
                    cout << "��ʱ: " << name << "״̬ : ";
                    color(11);
                    cout << "��ʱ���\n\n";
                    cout << "�����������";
                    if (_kbhit())
                    {
                        _getch();
                        flag = false;
                    }
                    Sleep(100);
                }
            }
        }
        else if (n == 5)
        {
            qp();
            cout << "����������:";
            string x2;
            cin >> x2;
            if (x2 == "8133t5&wth123")
            {
                cout << "��ӭ,����Ա";
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F1");
                    cout << "F1 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 21");
                    cout << "21 ʾ���ı�\n";
                }
                else
                {
                    system("color 01");
                    cout << "01 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F2");
                    cout << "F2 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 23");
                    cout << "23 ʾ���ı�\n";
                }
                else
                {
                    system("color 02");
                    cout << "02 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F3");
                    cout << "F3 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 24");
                    cout << "24 ʾ���ı�\n";
                }
                else
                {
                    system("color 03");
                    cout << "03 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F4");
                    cout << "F4 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 25");
                    cout << "25 ʾ���ı�\n";
                }
                else
                {
                    system("color 04");
                    cout << "04 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F5");
                    cout << "F5 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 26");
                    cout << "26 ʾ���ı�\n";
                }
                else
                {
                    system("color 05");
                    cout << "05 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F6");
                    cout << "F6 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 27");
                    cout << "27 ʾ���ı�\n";
                }
                else
                {
                    system("color 06");
                    cout << "06 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F7");
                    cout << "F7 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 28");
                    cout << "28 ʾ���ı�\n";
                }
                else
                {
                    system("color 07");
                    cout << "07 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F8");
                    cout << "F8 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 29");
                    cout << "29 ʾ���ı�\n";
                }
                else
                {
                    system("color 08");
                    cout << "08 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color F9");
                    cout << "F9 ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 2A");
                    cout << "2A ʾ���ı�\n";
                }
                else
                {
                    system("color 09");
                    cout << "09 ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color FA");
                    cout << "FA ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 2B");
                    cout << "2B ʾ���ı�\n";
                }
                else
                {
                    system("color 0A");
                    cout << "0A ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color FB");
                    cout << "FB ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 2C");
                    cout << "2C ʾ���ı�\n";
                }
                else
                {
                    system("color 0B");
                    cout << "0B ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color FC");
                    cout << "FC ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 2D");
                    cout << "2D ʾ���ı�\n";
                }
                else
                {
                    system("color 0C");
                    cout << "0C ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color FD");
                    cout << "FD ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 2E");
                    cout << "2E ʾ���ı�\n";
                }
                else
                {
                    system("color 0D");
                    cout << "0D ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                if (white == 1 && green == 0)
                {
                    system("color FE");
                    cout << "FE ʾ���ı�\n";
                }
                else if (green == 1)
                {
                    system("color 2F");
                    cout << "2F ʾ���ı�\n";
                }
                else
                {
                    system("color 0E");
                    cout << "0E ʾ���ı�\n";
                }
                cout << "�����������";
                _getch();
                qp();
                color(15);
                cout << "�ټ�������Ա��";
                cout << "�����������";
                _getch();
            }
        }
        else if (n == 6)
        {
            system("mode con cols=51 lines=17");
            qp();
            cout << "��˽��8133wt5(���)��fjxmwth(���)�Է�������(���)\n\n";
            cout << "��л��ķ��������ǻ�����һ���汾��������\n";
            cout << "��Ҫ�����������?(��'1��)\n";
            cout << "�����������(����1)\n";
            char xy;
            xy = _getch();
            if (xy == '1')
            {
                system("start https://www.luogu.com.cn/chat");
            }
            system("mode con cols=30 lines=17");
        }
        else if (n == 7)
        {
            while (1)
            {
                qp();
                cout << "״̬\n";
                cout << "ģʽ:";
                if (green == 1)
                {
                    cout << "�����ۡ�";
                }
                else if (white == 1)
                {
                    cout << "��ɫ";
                }
                else if (white == 0)
                {
                    cout << "��ɫ";
                }
                cout << '\n';
                cout << "��л:";
                if (fast == 1)
                    cout << "�ӿ�";
                else
                    cout << "����";
                cout << "\n\n\n";
                cout << "����\n";
                cout << "��c���л���ͷ���ڵ�ģʽ\n";
                cout << "��w����,��s����\n\n";
                if (green == 1)
                {
                    print("   ��ɫ   ", sz == 1, 0);
                    print("��ɫ(Ĭ��)", sz == 2, 0);
                }
                else if (white == 1)
                {
                    print("   ��ɫ   ", sz == 1, 0);
                    print(" �����ۡ� ", sz == 2, 0);
                }
                else if (white == 0)
                {
                    print("��ɫ(Ĭ��)", sz == 1, 0);
                    print(" �����ۡ� ", sz == 2, 0);
                }
                if (!fast)
                    print(" �ӿ���л ", sz == 3, 0);
                else
                    print(" ������л ", sz == 3, 0);
                print("   �˳�   ", sz == 4, 0);
                char ch = _getch();
                if (ch == 'c')
                    break;
                else if (ch == 'w')
                    sz = sz == 1 ? 4 : sz - 1;
                else if (ch == 's')
                    sz = sz == 4 ? 1 : sz + 1;
            }
            if (sz == 4)
                continue;
            else if (sz == 3)
                fast = !fast;
            if (green == 1)
            {
                green = 0;
                if (sz == 1)
                    white = 0;
                else if (sz == 2)
                    white = 1;
            }
            else if (white == 1)
            {
                if (sz == 1)
                    white = 0;
                else if (sz == 2)
                    green = 1;
            }
            else if (white == 0)
            {
                if (sz == 1)
                    white = 1;
                else if (sz == 2)
                    green = 1;
            }
        }
    }
    SendMessage(hwnd, WM_CLOSE, 0, 0);
}
