import json
import requests
import subprocess
import os
import sys
import tempfile
import shutil
from pathlib import Path

def check_for_updates(version_url, download_url=None, current_version="1.0.0"):
    """
    检测更新并自动下载解压
    
    Args:
        version_url (str): 版本信息JSON的URL (例如: https://username.github.io/repo/version.json)
        download_url (str, optional): 7z压缩包的下载URL，如果为None则从version.json获取
        current_version (str): 当前版本号
    
    Returns:
        bool: 是否有更新
    """
    try:
        # 获取远程版本信息
        print(f"正在检查更新... 当前版本: {current_version}")
        response = requests.get(version_url, timeout=10)
        response.raise_for_status()
        version_info = response.json()
        
        remote_version = version_info.get("version")
        changelog = version_info.get("changelog", "暂无更新日志")
        
        print(f"远程版本: {remote_version}")
        print(f"更新日志: {changelog}")
        
        # 比较版本
        if remote_version == current_version:
            print("当前已是最新版本")
            return False
        
        print(f"发现新版本 {remote_version}，开始下载...")
        
        # 确定下载URL
        if download_url is None:
            download_url = version_info.get("download_url")
            if not download_url:
                print("错误: 未指定下载链接")
                return False
        
        # 下载7z文件
        download_path = download_file(download_url)
        if not download_path:
            return False
        
        # 解压文件
        if extract_7z(download_path):
            print(f"更新完成！当前版本: {remote_version}")
            # 可选：删除下载的压缩包
            # os.remove(download_path)
            return True
        else:
            print("解压失败")
            return False
            
    except requests.RequestException as e:
        print(f"网络错误: {e}")
    except json.JSONDecodeError:
        print("版本信息格式错误")
    except Exception as e:
        print(f"更新过程出错: {e}")
    
    return False

def download_file(url):
    """
    下载文件到临时目录
    """
    try:
        # 创建临时文件
        temp_dir = tempfile.gettempdir()
        file_name = os.path.basename(url)
        if not file_name.endswith('.7z'):
            file_name = 'update.7z'
        
        local_path = os.path.join(temp_dir, file_name)
        
        print(f"下载中: {url}")
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        
        # 获取文件大小
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(local_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    # 显示进度
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        print(f"\r下载进度: {progress:.1f}%", end='')
        
        print("\n下载完成")
        return local_path
        
    except Exception as e:
        print(f"下载失败: {e}")
        return None

def extract_7z(archive_path):
    """
    解压7z文件到当前目录
    要求7z.exe在同目录下
    """
    try:
        current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        seven_zip = os.path.join(current_dir, "7z.exe")
        
        if not os.path.exists(seven_zip):
            print("错误: 未找到7z.exe")
            return False
        
        if not os.path.exists(archive_path):
            print("错误: 压缩包不存在")
            return False
        
        print("正在解压文件...")
        
        # 使用7z解压到当前目录，覆盖已有文件
        cmd = [
            seven_zip, 'x', archive_path,
            f'-o{current_dir}', '-y',  # -y 自动确认覆盖
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("解压成功")
            return True
        else:
            print(f"解压失败: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"解压过程出错: {e}")
        return False

# 使用示例
if __name__ == "__main__":
    # 测试代码
    VERSION_URL = "https://tt-tools-upd.github.io/123/version.json"
    CURRENT_VERSION = "1.0.0"
    
    check_for_updates(VERSION_URL, current_version=CURRENT_VERSION)