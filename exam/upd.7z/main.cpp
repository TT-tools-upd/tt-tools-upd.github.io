#include<bits/stdc++.h>
using namespace std;
int main()
{
    if(system("update")) return 0;
    cout<<"version:1.0.1"<<endl;
    system("pause"); 
    return 0;
}
